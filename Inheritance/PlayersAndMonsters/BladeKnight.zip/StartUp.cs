﻿using System;
using System.Collections.Generic;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //List<Wizard> wizardList = new();
            //var pesho = new Wizard("Pesho", 1);
            //var gosho = new DarkWizard("Gosho", 11);
            //var maria = new SoulMaster("Maria", 111);
            //wizardList.Add(pesho);
            //wizardList.Add(gosho);
            //wizardList.Add(maria);

            //foreach (var wizard in wizardList)
            //{
            //   // wizard.CastSpell();
            //    Console.WriteLine(wizard);
            //}
        }
    }
}