﻿namespace Collections.Interfaces
{
    public interface IAddElements
    {
        int Add(string input);
    }
}
