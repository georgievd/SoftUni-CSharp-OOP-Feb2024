﻿namespace Collections.Interfaces
{
    public interface IRemovable
    {
        string Remove();
    }
}
